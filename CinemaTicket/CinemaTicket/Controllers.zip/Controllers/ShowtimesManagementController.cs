﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CinemaTicket.Data;

namespace CinemaTicket.Controllers
{
    public class ShowtimeManagementController : Controller
    {
        private readonly CinemaTicketDbContext _context;

        public ShowtimeManagementController(CinemaTicketDbContext context)
        {
            _context = context;
        }

        //  Danh sách suất chiếu
        public async Task<IActionResult> Index()
        {
            var showtimes = await _context.Showtimes.Include(s => s.Movie).Include(s => s.Room).ToListAsync();
            return View(showtimes);
        }

        //  Form thêm suất chiếu
        public IActionResult Create()
        {
            var movies = _context.Movies.ToList();
            var rooms = _context.Rooms.ToList();
            ViewBag.Movies = movies ?? new List<Movie>();  // Đảm bảo không null
            ViewBag.Rooms = rooms ?? new List<Room>();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Showtime showtime)
        {
            Console.WriteLine($"MovieId: {showtime.MovieId}, RoomId: {showtime.RoomId}, ShowTime: {showtime.ShowTime}");

            if (!ModelState.IsValid)
            {
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine($"Validation Error: {error.ErrorMessage}");
                }
            }

            if (ModelState.IsValid)
            {
                showtime.CreatedAt = DateTime.Now;
                showtime.UpdatedAt = DateTime.Now;
                _context.Add(showtime);
                int result = await _context.SaveChangesAsync();
                Console.WriteLine($"Rows affected: {result}");

                return RedirectToAction(nameof(Index));
            }

            ViewBag.Movies = _context.Movies.ToList() ?? new List<Movie>();
            ViewBag.Rooms = _context.Rooms.ToList() ?? new List<Room>();
            return View(showtime);
        }




        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var showtime = await _context.Showtimes.FindAsync(id);
            if (showtime == null)
            {
                return NotFound();
            }

            // Load danh sách phim và phòng chiếu
            ViewBag.Movies = await _context.Movies.ToListAsync();
            ViewBag.Rooms = await _context.Rooms.ToListAsync();

            return View(showtime);
        }




        [HttpPost]
        public async Task<IActionResult> Edit(Showtime showtime)
        {
            Console.WriteLine($"Received ShowtimeId: {showtime.ShowtimeId}");
            if (!ModelState.IsValid)
            {
                Console.WriteLine("ModelState is not valid!");
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine($"Validation Error: {error.ErrorMessage}");
                }
                ViewBag.Movies = await _context.Movies.ToListAsync();
                ViewBag.Rooms = await _context.Rooms.ToListAsync();
                return View(showtime);
            }

            var existingShowtime = await _context.Showtimes.FindAsync(showtime.ShowtimeId);
            if (existingShowtime == null)
            {
                Console.WriteLine("Showtime not found!");
                return NotFound();
            }

            existingShowtime.MovieId = showtime.MovieId;
            existingShowtime.RoomId = showtime.RoomId;
            existingShowtime.ShowTime = showtime.ShowTime;
            existingShowtime.UpdatedAt = DateTime.Now;

            int result = await _context.SaveChangesAsync();
            Console.WriteLine($"Rows affected: {result}");

            return RedirectToAction("Index");
        }






        // 6️⃣ Xóa suất chiếu
        public async Task<IActionResult> Delete(int id)
        {
            var showtime = await _context.Showtimes.FindAsync(id);
            if (showtime == null) return NotFound();

            _context.Showtimes.Remove(showtime);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
